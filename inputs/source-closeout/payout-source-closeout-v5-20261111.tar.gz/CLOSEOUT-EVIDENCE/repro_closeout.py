#!/usr/bin/env python3
"""Reproduce the three v4-closeout counterexamples against the SUPPLIED v4 code.

  C1 FastNEAR response missing top-level execution_outcome -> falls back to first
     receipt; source_status Unknown, complete=true, ALL_ROWS_OBSERVED.
  C2 Valid supported burn + extra supported nep141 ft_burn whose data is a string
     -> extra event silently skipped; ALL_ROWS_OBSERVED.
  C3 null entry in receipts_outcome beside a valid outcome -> AttributeError in
     extract_burns.

Usage: python3 repro_closeout.py <pkg_root> <outdir>
"""
import contextlib, copy, importlib.util, io, json, sys
from pathlib import Path

pkg = Path(sys.argv[1]).resolve()
outdir = Path(sys.argv[2]).resolve()
outdir.mkdir(parents=True, exist_ok=True)

spec = importlib.util.spec_from_file_location("pp_closeout", pkg / "payout_probe.py")
pp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pp)

single = json.loads((pkg / "fixtures/fx_g1_drpc_observed.json").read_text())
sys.path.insert(0, str(pkg))
import importlib.util as ilu
ispec = ilu.spec_from_file_location("invbuilders", pkg / "run_invariants.py")
ib = ilu.module_from_spec(ispec)
ispec.loader.exec_module(ib)

findings = {}

def run(name, case):
    case["name"] = name
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        report = pp.run_case(case, outdir)
    findings[name] = {"overall": report["summary"]["overall"],
                      "source_status": report["summary"]["source_status"],
                      "complete": report["summary"]["completeness"]["complete"],
                      "verdicts": [r["verdict"] for r in report["results"]]}
    (outdir / (name + ".json")).write_text(json.dumps(report, indent=2) + "\n")

# C1: FastNEAR without top-level execution_outcome (transaction root)
c = ib.build_case("fastnear_missing_transaction_root", 1, 1, "full", source="fastnear")
c["legs"]["near_raw"].pop("execution_outcome")
run("C1_fastnear_missing_transaction_root", c)

# C2: valid burn plus an additional supported ft_burn with data as a string
c = copy.deepcopy(single)
oc = c["legs"]["near_raw"]["receipts_outcome"][0]["outcome"]
ev = json.loads(oc["logs"][0].split("EVENT_JSON:", 1)[1])
extra = copy.deepcopy(ev)
extra["data"] = "malformed-data-array"
oc["logs"].append("EVENT_JSON:" + json.dumps(extra))
run("C2_valid_burn_plus_string_data_burn", c)

# C3: null entry beside a valid receipts_outcome entry
c = copy.deepcopy(single)
c["legs"]["near_raw"]["receipts_outcome"].append(None)
try:
    run("C3_null_receipts_outcome_entry", c)
    findings["C3_null_receipts_outcome_entry"]["exception"] = None
except Exception as exc:
    findings["C3_null_receipts_outcome_entry"] = {
        "exception": type(exc).__name__, "message": str(exc)}

print(json.dumps(findings, indent=2))
(outdir / "summary.json").write_text(json.dumps(findings, indent=2) + "\n")
