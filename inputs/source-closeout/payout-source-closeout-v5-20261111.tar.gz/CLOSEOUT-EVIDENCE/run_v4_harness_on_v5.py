#!/usr/bin/env python3
"""Run the SUPPLIED reviewer's check_v4.py harness (mutation logic unchanged)
against the v5 closeout package. Only the package path is adapted.

Usage: python3 run_v4_harness_on_v5.py
"""
import contextlib, copy, importlib.util, io, json, shutil, subprocess, sys
from pathlib import Path

REPAIRED = Path("/home/z/my-project/review/closeout/repaired").resolve()
OUTDIR = Path("/home/z/my-project/review/closeout/reviewer_harness_v5").resolve()
OUTDIR.mkdir(parents=True, exist_ok=True)

work = OUTDIR / "pkg"
if work.exists():
    shutil.rmtree(work)
shutil.copytree(REPAIRED, work)
shutil.rmtree(work / "results", ignore_errors=True)

results = {}
for script, label in (("run_tests.py", "suite"), ("verify_outputs.py", "verifier_fresh"),
                      ("run_invariants.py", "generated_invariants"),
                      ("repro_all.py", "ten_regressions")):
    r = subprocess.run([sys.executable, "-B", script], cwd=work,
                       capture_output=True, text=True)
    (OUTDIR / (label + ".txt")).write_text(r.stdout + r.stderr)
    results[label] = {"exit_code": r.returncode,
                      "pass": r.stdout.count("[PASS]"),
                      "fail": r.stdout.count("[FAIL]")}

spec = importlib.util.spec_from_file_location("v5_probe", work / "payout_probe.py")
pp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pp)
single = json.loads((work / "fixtures/fx_g1_drpc_observed.json").read_text())
grouped = json.loads((work / "fixtures/fx_g3_grouped_rows.json").read_text())
findings = {}

def run(name, case):
    case["name"] = name
    with contextlib.redirect_stdout(io.StringIO()):
        report = pp.run_case(case, OUTDIR / "adversarial")
    findings[name] = {"overall": report["summary"]["overall"],
                     "source_status": report["summary"]["source_status"],
                     "complete": report["summary"]["completeness"]["complete"]}
    return report

def group_two():
    c = copy.deepcopy(grouped)
    c["legs"]["near_raw"]["receipts_outcome"][0]["outcome"]["logs"] = \
        c["legs"]["near_raw"]["receipts_outcome"][0]["outcome"]["logs"][:2]
    rec = c["legs"]["bridge_raw"]["withdrawals"][0]
    other = copy.deepcopy(rec); other["data"]["transfer_tx_hash"] = "0x" + "4" * 64
    c["legs"]["bridge_raw"]["withdrawals"].append(other)
    return c

# --- reviewer's ten prior cases (logic identical to check_v4.py) ---
c = group_two()
for rec in c["legs"]["bridge_raw"]["withdrawals"]:
    rec["status"] = "PENDING"; rec["data"]["transfer_tx_hash"] = None
c["legs"]["bridge_raw"]["withdrawals"][1]["data"]["tx_hash"] = "TX_G2"
c["legs"]["dest_receipts"] = {}
run("group_all_pending", c)
c = group_two(); c["legs"]["dest_unavailable"] = "timeout"
run("group_destination_unavailable", c)
c = group_two()
for rec in c["legs"]["bridge_raw"]["withdrawals"]:
    c["legs"]["dest_receipts"][rec["data"]["transfer_tx_hash"]] = \
        {"status": "0x1", "blockNumber": "0x64", "logs": []}
run("group_zero_matching_transfers", c)
c = copy.deepcopy(single)
c["legs"]["bridge_raw"]["withdrawals"][0]["data"]["withdrawal_fee"] = "999"
run("inconsistent_fee_arithmetic", c)
c = copy.deepcopy(single)
raw = c["legs"]["near_raw"]
raw["receipts_outcome"][0]["outcome"]["receipt_ids"] = ["missing-child"]
raw["receipts_outcome"].append({"id": "missing-child"})
run("reachable_outcome_wrapper_without_execution", c)
c = copy.deepcopy(single)
tx = next(iter(c["legs"]["dest_receipts"]))
c["legs"]["dest_receipts"][tx]["transactionHash"] = "0x" + "f" * 64
run("receipt_transaction_hash_mismatch", c)
c = copy.deepcopy(single)
del c["legs"]["near_raw"]["receipts_outcome"][0]["outcome"]["receipt_ids"]
run("missing_child_edges_field", c)
c = copy.deepcopy(single)
d = c["legs"]["bridge_raw"]["withdrawals"][0]["data"]
d["amount"] = 10000.75; d["withdrawal_fee"] = 2400.5; d["withdraw_amount"] = 7600.25
run("fractional_integer_fields", c)
c = copy.deepcopy(single)
c["legs"]["bridge_raw"]["withdrawals"].append(None)
run("malformed_extra_bridge_record", c)
c = copy.deepcopy(single)
oc = c["legs"]["near_raw"]["receipts_outcome"][0]["outcome"]
ev = json.loads(oc["logs"][0].split("EVENT_JSON:", 1)[1]); ev["data"][0]["amount"] = "not-an-integer"
oc["logs"][0] = "EVENT_JSON:" + json.dumps(ev)
try:
    run("malformed_source_burn_amount", c)
except Exception as exc:
    findings["malformed_source_burn_amount"] = {"exception": type(exc).__name__}

# --- reviewer's three NEW v4-closeout cases (logic identical) ---
c = copy.deepcopy(single)
oc = c["legs"]["near_raw"]["receipts_outcome"][0]["outcome"]
ev = json.loads(oc["logs"][0].split("EVENT_JSON:", 1)[1]); ev["data"] = "malformed-data-array"
oc["logs"].append("EVENT_JSON:" + json.dumps(ev))
run("malformed_additional_burn_data_array", c)

ispec = importlib.util.spec_from_file_location("v5_builders", work / "run_invariants.py")
ib = importlib.util.module_from_spec(ispec)
ispec.loader.exec_module(ib)
c = ib.build_case("fastnear_missing_transaction_root", 1, 1, "full", source="fastnear")
c["legs"]["near_raw"].pop("execution_outcome")
run("fastnear_missing_transaction_root", c)

c = copy.deepcopy(single)
c["legs"]["near_raw"]["receipts_outcome"].append(None)
try:
    run("malformed_source_outcome_entry", c)
except Exception as exc:
    findings["malformed_source_outcome_entry"] = {"exception": type(exc).__name__}

out = {"suite_runs": results,
       "counterexamples": {k: (v.get("overall") if "overall" in v else v)
                           for k, v in findings.items()}}
print(json.dumps(out, indent=2))
(OUTDIR / "checks.json").write_text(json.dumps(
    {"suite_runs": results, "counterexamples": findings}, indent=2, default=str) + "\n")
