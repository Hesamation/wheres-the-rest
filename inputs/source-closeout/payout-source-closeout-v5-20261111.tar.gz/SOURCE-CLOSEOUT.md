# SOURCE-CLOSEOUT — v5 source-boundary validation closeout

Date: 2026-11-11 · Session: the same GLM session that produced v4 (per
PAYOUT-V4-SOURCE-CLOSEOUT.md this is the finite closeout that review asked for).
Scope: exactly the three demonstrated source-ingestion failures; no matcher
redesign, no scope widening, no UI, no pivot decision, no new research.

## Verdict for this closeout scope

**Closed.** All three reproduced failures now return conservative structured
results through the full `run_case` pipeline; the prior ten repairs still hold;
all suites pass from clean outputs; the saved success controls are unchanged.
Remaining limits are listed below and are deliberately proportional — this does
NOT claim all possible malformed JSON is now proved safe.

## Inputs confirmed

- `glm-v4-source-closeout-inputs-20261111.tar.gz` — extracted to an isolated
  directory before any execution. The embedded `payout-acceptance-v4-20261111.tar.gz`
  is byte-identical (SHA-256 `3b87cd9a281f9e8a58072f7265136a5ef19acde2e974c111047da2355f4cbf68`)
  to the v4 package delivered earlier this session.
- `V4-ACCEPTANCE-REVIEW.md`, `PAYOUT-V4-SOURCE-CLOSEOUT.md`,
  `GLM-SOURCE-CLOSEOUT-START.md` — read.
- `v4-review-evidence/check_v4.py` + `checks.json` — read; the harness itself
  was inspected before being re-used (path adaptation only, mutation logic
  unchanged) as an external cross-check.
- Missing inputs: none.

All prior packages, reports and the uploaded files are preserved unchanged;
the v5 work happened in a separate directory and is returned as a separately
versioned package.

## Baseline reproduction (supplied v4 code, clean outputs)

```
python3 run_tests.py        # 137 PASS, 0 FAIL, exit 0
python3 verify_outputs.py   #  30 PASS, 0 FAIL, exit 0
python3 run_invariants.py   # 111 PASS, 0 FAIL, exit 0
python3 repro_all.py        #   10 PASS, 0 FAIL, exit 0
```

The three closeout counterexamples reproduced exactly as the reviewer recorded
(`CLOSEOUT-EVIDENCE/counterexamples_before/`):

| Case | v4 behavior | Reviewer claim |
|---|---|---|
| FastNEAR `execution_outcome` removed (receipt+burn otherwise present) | source_status Unknown, complete=true, ALL_ROWS_OBSERVED | confirmed |
| valid burn + extra supported `ft_burn` with string `data` | extra event silently skipped; ALL_ROWS_OBSERVED | confirmed |
| `null` entry in `receipts_outcome` | `AttributeError: 'NoneType' object has no attribute 'get'` | confirmed |

None of the reviewer's three claims was found invalid.

## Evidence for the chosen rule (real saved responses)

- FastNEAR: every transaction in `raw/fastnear_txs_probe.json` (2/2) and the
  offline_control fixture carries a top-level `execution_outcome` with
  `outcome.receipt_ids` as a list — the root is always present in real saved
  successful responses, so requiring it rejects no legitimate evidence we hold.
  No alternate root binding exists in any saved FastNEAR response; therefore no
  "sufficient alternate binding" is documented (the brief allows documenting one
  only if supported by actual endpoint evidence, and it is not).
- drpc: `raw/near_qa1_full.json` and `near_qa2_full.json` both carry
  `transaction_outcome.outcome.receipt_ids` as a list; all 20/14
  `receipts_outcome` entries are objects with object `outcome`s.
- Hence the one coherent source-boundary rule: **the transaction root
  (drpc `transaction_outcome`, FastNEAR `execution_outcome`) is required graph
  structure — present, object-shaped, with a list-typed child-edge array — and
  roots are never guessed from receipt ordering; and every entry of the source
  outcome/receipt collections must be an object with object-typed nested
  outcomes before dereferencing, with recognized supported-scope burn events
  requiring list-typed `data`.**

## Fixes applied (one coherent validator, marked `[v5]` in source)

1. **Transaction root required, both shapes** (`analyze_completeness`): drpc
   `transaction_outcome` and FastNEAR `execution_outcome` must be present,
   object-typed, with `outcome.receipt_ids` present and a list. Absent, null,
   non-object root, missing/non-list child array → `INCOMPLETE_EVIDENCE`
   ("malformed transaction root: …"). The old FastNEAR first-receipt fallback
   (and the drpc first-outcome fallback) are removed — no root guessing.
2. **Source collection entries validated before dereference**
   (`extract_burns`, both branches): null/str/number entries in
   `receipts_outcome` (drpc) or `receipts` (FastNEAR) are counted in
   `diag['malformed_entries']` and reach the report as
   `UNSUPPORTED_SOURCE — malformed source entries (N …)` — never green, never a
   crash. Nested non-object `outcome`/`execution_outcome` become wrappers
   without execution evidence → unresolved for completeness.
3. **Recognized burn `data` shape policy** (`_burn_from_log`): a supported-executor
   nep141 `ft_burn` with absent/null/object/string `data` yields a structured
   `INVALID_EVENT_ROW` (→ INVALID_EVIDENCE) instead of a silent skip. Exact
   policy for the neighboring classes (stated in the docstring and asserted by
   the new policy tests): unrelated standards/events (ft_transfer, nep245,
   ft_metadata) → ignored, no row; valid list-data burns without a string
   `WITHDRAW_TO:` memo (plain burns, other memos, null/number memo) → ignored,
   not withdrawal failures; malformed burns emitted by an OUT-OF-SCOPE executor →
   `UNSUPPORTED_SCOPE` (scope precedence now checked before malformed_event in
   `reconcile`), because the supported task never claims other contracts' events.
4. **Chain-dereference crashes fixed** (`run_case` source_status computation in
   both branches, `_normalize_fastnear_tx`): a non-dict
   `execution_outcome`/`outcome` no longer raises `AttributeError` inside the
   pipeline; the malformed-root evidence flows to the structured report. (These
   were found by the new invariants cases exercising the same mutation family
   through the full pipeline.)

## Commands and measured results (v5, clean outputs)

```
python3 run_tests.py        # 174 PASS, 0 FAIL, exit 0
python3 verify_outputs.py   #  30 PASS, 0 FAIL, exit 0
python3 run_invariants.py   # 142 PASS, 0 FAIL, exit 0
python3 repro_all.py        #   10 PASS, 0 FAIL, exit 0  (prior ten regressions)
python3 repro_closeout.py  #   3/3 conservative (six+four+three all replayable
                            #   via CLOSEOUT-EVIDENCE/reviewer_harness_v5)
```

The supplied reviewer's own `check_v4.py` mutation logic, re-pointed at this
package (paths only), reports all 13 mutations conservative: the ten prior
cases unchanged (IN_PROGRESS / INCONCLUSIVE / MISMATCH / INVALID_EVIDENCE /
INCOMPLETE_EVIDENCE / INCONCLUSIVE / INCOMPLETE_EVIDENCE / INVALID_EVIDENCE ×3)
plus the three new ones now INCOMPLETE_EVIDENCE / INVALID_EVIDENCE /
UNSUPPORTED_SOURCE. Suite counts are coverage of the enumerated mutation
classes, not a correctness proof; the delta from 137→174 and 111→142 is the
required new coverage (root variants, outcome-entry variants, burn-data
variants, policy classes), not an inflated metric.

Offline real-evidence controls classify identically to v4: offline_qa1 MISMATCH,
offline_qa2 MISMATCH, offline_control ALL_ROWS_OBSERVED. All 27 fixture
expectations pass.

## Exact remaining failures

- None demonstrated within the tested input space. Three classes are known-open
  by design and unchanged from v4: receipt-graph expansion beyond the saved
  endpoint shapes is not implemented (unresolved → INCOMPLETE_EVIDENCE);
  chains/tokens outside the supported scope are UNSUPPORTED; OBSERVED_MATCH
  remains receipt-level (no finality/settlement claim).
- Conservative-direction notes: integral-valued floats for money are still
  rejected (INVALID_EVIDENCE, not accepted); a FastNEAR response whose root is
  legitimately absent but whose graph is otherwise complete would be classified
  INCOMPLETE_EVIDENCE — no such response exists in the saved evidence, and the
  brief forbids guessing alternate bindings without actual endpoint evidence.

## Proportional limits (not a safety claim)

- All malformed-input tests are synthetic mutations of endpoint-shaped
  fixtures. No evidence any public endpoint emitted these shapes; no loss, no
  exploitability, no production-audit conclusion follows.
- "Malformed evidence never produces success" is verified for the enumerated
  variants (root, entries, nested outcomes, burn data, money types, bridge
  entries), not for all conceivable malformed JSON.
- Same-session repair/review limitation: this session both produced v4 and
  performed the v5 closeout; the independent cross-check is the reviewer's own
  harness logic re-run on the repaired code, which agrees on all 13 mutations.
  That is code-path independence, not researcher independence.
- No live traffic was generated; conclusions rest on saved raw evidence and
  synthetic structure/type mutations. No keys, funds, credentials, deployment,
  publication or outreach occurred.
- Strategic decisions (pivot, track, demand, delivery capacity) remain with the
  human; a thin UI remains a candidate next step after that choice, per the
  v4 acceptance review.
